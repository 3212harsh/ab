const { response } = require("express");

function success(ans,i){
    let feild = document.getElementById(`question${i}`)
    let data = `<input value='${ans}' class = "done" >`
    feild.innerHTML = data
}

function secsavesus(m,i){
    if (m==1){
        let a = document.getElementById("markasdone");
        a.innerHTML="";
        window.location.reload();
    }
}

function savesection(i){
    let a = window.location.pathname.split('/');
    fetch(`http://localhost:3000/sectiondone/${a[2]}/${a[3]}`)
    .then(response=>{
        return response.json();
    })
    .then(data =>{
        return secsavesus(data.message,i);
    })
    .catch(err=>{
        console.log(err);
    })
}

function done(i)
{
    let a = document.getElementById("markasdone")
    let code = `<button id='sectiondone' onclick='savesection(${i})'>Mark as completed </button>`
    a.innerHTML= code
}

function failed(){
    console.log("failed");
}

function submit(i){
    let b = document.getElementById(`ans${i}`)
    let ans = b.value;
    let data = {
        ans:ans,
        index:i
    }
    fetch(`${window.location.pathname}`,{
        method:'POST',
        headers:{
            'Content-type' : 'application/json'
        },
        body : JSON.stringify(data)
    })
    .then(response =>{
        return response.json();
    })
    .then(data =>{
        if (data.message === 1){
            success(ans,i);
        }
        else{
            failed();
        }
        if (data.all === 1){
            done(i);
        }
    })
    .catch(err => {
        console.log(err);
    })
}

