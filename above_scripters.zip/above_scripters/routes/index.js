var express = require('express');
var router = express.Router();
let usermodel = require('./users');
let modulemodel = require('./module');
let pathmodel = require('./paths');
let challmodel = require('./ctf');
let roommodel = require('./newrooms');
let functions = require('./functions');
const passport = require('passport');
const localstatergy = require('passport-local');
const users = require('./users');


passport.use(new localstatergy(usermodel.authenticate()));

router.get('/',isloggedin ,async function(req, res, next) {
  let user = await usermodel.findOne({
    username:req.session.passport.user
  }).populate('enrolled_path');
  let newrooms = await roommodel.find();
  console.log(newrooms);
  res.render('index',{user,newrooms});
});

router.post('/login', passport.authenticate('local',{
  successRedirect : '/',
  failureRedirect : '/login',
}),function(req,res){});

router.post('/register',function(req,res){
  let user = new usermodel({
    username : req.body.username,
    email : req.body.email,
  });
  usermodel.register(user,req.body.password,function(err){
    if (err) return res.send(err);
    passport.authenticate('local')(req,res,function(){
      res.redirect('/');
    });
  }); 
});

router.get('/modules',isloggedin,async function(req,res){
  let user = await usermodel({
    username : req.session.passport.user
  });
  let mod = await modulemodel.find();
  res.render('modules',{user,mod});
})

router.post('/learning/:moduleid/:sectionname', isloggedin , async function(req, res) {  
  let mod = await modulemodel.findById(req.params.moduleid);
  if (mod) {
    let sec =await mod.section.find(section => section.sectionname === req.params.sectionname);
    if (sec) {
      let data = req.body.ans;
      let index = req.body.index;
      if (data && index !== undefined) {
        if (sec.answers[index] === data) {
          req.session.section[index]=1;
          let flag = functions.sectiondone(req.session.section);
          if (flag){
            return res.json({message:1,all:1});  
          }
          return res.json({message:1,all:0});
          
        } else {
          return res.json({message:0,all:0});
        }
      } else {
        console.log("Data not received");
      }
    }
  }
  res.json({message:2});
});

router.get('/register',function(req,res){
  res.render('register');
});

router.get('/addmodule',function(req,res){
  res.render('addmodule');
});

router.post('/addmodule',async function(req,res){
  let mod = new modulemodel({
    modulename : req.body.modulename,
    catagory : req.body.catagory.split(','),
    image : req.body.image,
    difficulty : req.body.difficulty,
  });
  await mod.save();
  res.send('done')
});

router.post('/addsection',async function(req,res){
  let modname = req.body.modulename;
  let mod =await modulemodel.findOne({modulename:modname})
  console.log(modname);
  if(!mod){
    return res.send("Module not found");
  }
  
  mod.section.push({
      sectionname:req.body.sectionname,
      data:req.body.data,
      questions:req.body.questions.split(','),
      answers:req.body.answers.split(',')
    });
  mod.save();
    res.send("Module added successfylly");
  
});

router.get('/login',function(req,res){
  res.render('login');
});

router.get('/learning/:module_id', isloggedin ,async function(req,res){
  let mod = await modulemodel.findById(req.params.module_id);
  let arr = [];
  for(i=0;i<mod.section[0].questions.length;i++)
  {
    arr.push(0);
  }
  req.session.section = arr;
  console.log(req.session.section);
  let user = await usermodel.findOne({
    username : req.session.passport.user
  });
  res.render('learning',{mod,sec:null,user});
});

router.get('/learning/:module_id/:sectionname', isloggedin ,async function(req,res){
  let mod = await modulemodel.findById(req.params.module_id);
  let sec = mod.section.find(section => section.sectionname === req.params.sectionname);
  let arr = [];
  for(i=0;i<sec.questions.length;i++)
  {
    arr.push(0);
  }
  req.session.section = arr;
  console.log(req.session.section);
  let user = await usermodel.findOne({
    username : req.session.passport.user
  });
  res.render('learning',{mod,sec,user});
});

router.get('/sectiondone/:mid/:sname', isloggedin ,async function(req,res){
  let mod = await modulemodel.findById(req.params.mid);
  if(mod) {
    let sec = mod.section.find(section=>section.sectionname===req.params.sname)
    if(sec){
      let user = await usermodel.findOne({username:req.session.passport.user})
      await user.sectiondone.push(sec._id);
      await user.save();
      res.json({message:1})
    }
    else{
      res.json({message:0})
    }
  }
  else{
    res.json({message:0});s
  }
});

router.get('/path/all',isloggedin,async function(req,res){
  let user = await usermodel.findOne({username:req.session.passport.user});
  let paths = await pathmodel.find();
  console.log(paths);
  res.render('allpath',{user,paths});
})

router.get('/path/enrolled_paths',isloggedin,async function(req,res){
  let user = await usermodel.findOne({username:req.session.passport.user}).populate('enrolled_path');
  res.render('path',{user});
})

router.get('/addpath',isloggedin,function(req,res){
  res.render('addpath',);
})

router.post('/addpath',isloggedin, async function(req,res){
  let path = new pathmodel({
    pathname:req.body.pathname,
    title:req.body.title,
    discription:req.body.discription,
    image: req.body.image,
    level:req.body.level,
    pathtype:req.body.pathtype,
  });
  await path.save();
  res.send('done');
});

router.post('/addpath/part',isloggedin,async function(req,res){
  let path = await pathmodel.findOne({pathname:req.body.pathname});
  path.parts.push({
    part_name:req.body.part_name,
    part_discription:req.body.part_discription,
    part_image:req.body.part_image,
    modules:req.body.modules.split(','),
  })
  path.save();
  res.send('done')
});

router.get('/enroll/:pathname',isloggedin,async function(req,res){
  let user = await usermodel.findOne({username:req.session.passport.user});
  let path = await pathmodel.findOne({pathname:req.params.pathname});
  if (path) {
    await user.enrolled_path.push(path._id);
    await user.save();
    return res.redirect(`/path/enrolled_paths/`)
  }
  res.send("failed");
});

router.get('/createCTF',function(req,res){
  res.render('ctf');
})

router.get('/machine',function(req,res){
  res.render('m');
})

router.get('/path/:pathname',async function(req,res){
  let path = await pathmodel.findOne({pathname:req.params.pathname}).populate('parts.modules');
  res.render('part_path',{path});
  
})

router.get('/addchallenge',isloggedin,function(req,res){
  res.render('addchallenge');
})
router.post('/addchallenge', isloggedin, async function(req, res) {

  let challenge = new challmodel({
    name: req.body.name,
    discription: req.body.discription,
    image: req.body.image,
    flag: req.body.flag,
    link: req.body.link,
    lev: req.body.level, 
    type: req.body.type,
  });
  await challenge.save();
  res.send("done");
});

router.post('/showchallenge',async function(req,res){
  let c = [];
  let challenge = await challmodel.find({type:req.body.type});
  challenge.forEach((chal)=>{
    c.push({"name":chal.name,"level":chal.lev});
  });
  res.json(c);
});

function isloggedin (req,res,next)
{
  if (req.isAuthenticated()) return next();
  res.redirect('/login');
}


module.exports = router;
