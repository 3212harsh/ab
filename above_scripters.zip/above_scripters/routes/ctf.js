let mongoose = require('mongoose');
let ctfschema = mongoose.Schema({
    name : String,
    image:String,
    discription:String,
    flag:String,
    link:String,
    type:String,
    lev:String,
});

module.exports = mongoose.model('challenge',ctfschema);