function sectiondone(a){
    let flag = 0;
    for(i=0;i<a.length;i++)
    {
        if (a[i] == 0)
        {
            flag+=1;
        }
    }
    if(flag==0){
        return true;  
    }
    return false;
}

module.exports = {sectiondone};